package com.yuvashaktigroup.app;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.util.Base64;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;

/**
 * युवा शक्ति ग्रुप (भाटी परिवार • कुचेरा) — Android WebView wrapper
 *
 * असली ऐप (UI + सारा business logic + Firebase) assets/index.html में है।
 * यह क्लास सिर्फ़ उसे WebView में लोड करती है और index.html से आने वाली
 * window.AndroidApp.* कॉल्स को असली Android फ़ीचर्स (शेयर, नोटिफ़िकेशन,
 * PDF, APK इंस्टॉल) से जोड़ती है।
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "YuvaShaktiApp";
    private static final String CHANNEL_ID = "yuva_shakti_channel";
    private static final String FILE_PROVIDER_AUTHORITY = "com.yuvashaktigroup.app.fileprovider";

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    private final ActivityResultLauncher<Intent> fileChooserLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (filePathCallback == null) return;
                Uri[] results = null;
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri data = result.getData().getData();
                    if (data != null) results = new Uri[]{data};
                }
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            });

    private final ActivityResultLauncher<String> notifPermLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                Log.d(TAG, "Notification permission granted=" + granted);
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);
        createNotificationChannel();

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // localStorage / IndexedDB
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportMultipleWindows(false);

        webView.addJavascriptInterface(new AndroidAppBridge(), "AndroidApp");
        webView.setWebViewClient(new WebViewClient());

        webView.setWebChromeClient(new WebChromeClient() {
            // फ़ोटो अपलोड (कैमरा / गैलरी) — <input type="file" accept="image/*" capture>
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                              FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = params.createIntent();
                try {
                    fileChooserLauncher.launch(intent);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }

            // कैमरा परमिशन (फ़ोटो/वीडियो कैप्चर के लिए)
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });

        // ऐप के अंदर ही बैक बटन काम करे (ब्राउज़र हिस्ट्री की तरह)
        getOnBackPressedDispatcher().addCallback(this, new androidx.activity.OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack();
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });

        // असली ऐप — index.html — लोड करें
        webView.loadUrl("file:///android_asset/index.html");

        requestNotifPermissionIfNeeded();
    }

    private void requestNotifPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
            }
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "युवा शक्ति ग्रुप सूचनाएं", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("सुविचार, अंशदान रिमाइंडर व अन्य सूचनाएं");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    /**
     * index.html के JS से window.AndroidApp.<method>(...) के ज़रिए कॉल होने वाला ब्रिज।
     * हर मेथड asset HTML में इस्तेमाल हुए नाम व सिग्नेचर से बिल्कुल मेल खाता है।
     */
    private class AndroidAppBridge {

        // एक base64 data URL (data:image/jpeg;base64,....) को कैश फ़ाइल में लिखकर
        // शेयर करने लायक content:// Uri लौटाता है
        private Uri writeDataUrlToCache(String dataUrl, String subDir, String fileName) throws Exception {
            String base64 = dataUrl.substring(dataUrl.indexOf(",") + 1);
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            File dir = new File(getCacheDir(), subDir);
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, fileName);
            try (FileOutputStream fos = new FileOutputStream(file)) {
                fos.write(bytes);
            }
            return FileProvider.getUriForFile(MainActivity.this, FILE_PROVIDER_AUTHORITY, file);
        }

        // ---- रसीद / सुविचार कार्ड जैसी इमेज को शेयर शीट (WhatsApp आदि) में भेजना ----
        @JavascriptInterface
        public void shareImage(String dataUrl, String caption) {
            runOnUiThread(() -> {
                try {
                    Uri uri = writeDataUrlToCache(dataUrl, "images", "share_" + System.currentTimeMillis() + ".jpg");
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType("image/jpeg");
                    intent.putExtra(Intent.EXTRA_STREAM, uri);
                    if (caption != null && !caption.isEmpty()) {
                        intent.putExtra(Intent.EXTRA_TEXT, caption);
                    }
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(Intent.createChooser(intent, "रसीद/कार्ड शेयर करें"));
                } catch (Exception e) {
                    Log.e(TAG, "shareImage failed", e);
                    Toast.makeText(MainActivity.this, "इमेज शेयर नहीं हो सकी", Toast.LENGTH_SHORT).show();
                }
            });
        }

        // ---- केवल टेक्स्ट शेयर करना (जैसे WhatsApp संदेश) ----
        @JavascriptInterface
        public void shareText(String text) {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TEXT, text);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(Intent.createChooser(intent, "शेयर करें"));
            });
        }

        // ---- सीधे WhatsApp खोलना (wa.me / api.whatsapp.com लिंक) ----
        @JavascriptInterface
        public void openWhatsApp(String url) {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "WhatsApp नहीं खुल सका", Toast.LENGTH_SHORT).show();
                }
            });
        }

        // ---- स्थानीय पुश-जैसा नोटिफ़िकेशन दिखाना (ऐप खुला/बैकग्राउंड में होने पर) ----
        @JavascriptInterface
        public void postNotification(String title, String body) {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                        ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.POST_NOTIFICATIONS)
                                != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                Intent openIntent = new Intent(MainActivity.this, MainActivity.class);
                PendingIntent pi = PendingIntent.getActivity(MainActivity.this, 0, openIntent,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

                NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity.this, CHANNEL_ID)
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setContentTitle(title)
                        .setContentText(body)
                        .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                        .setAutoCancel(true)
                        .setContentIntent(pi)
                        .setPriority(NotificationCompat.PRIORITY_HIGH);

                androidx.core.app.NotificationManagerCompat.from(MainActivity.this)
                        .notify((int) System.currentTimeMillis(), builder.build());
            });
        }

        // ---- नोटिफ़िकेशन परमिशन माँगना (Android 13+) ----
        @JavascriptInterface
        public void requestNotificationPermission() {
            runOnUiThread(MainActivity.this::requestNotifPermissionIfNeeded);
        }

        // ---- खाता-बही (ledger) को PDF के रूप में सेव करना ----
        @JavascriptInterface
        public void saveLedgerPdf(String base64Pdf, String fileName) {
            runOnUiThread(() -> {
                try {
                    byte[] bytes = Base64.decode(
                            base64Pdf.contains(",") ? base64Pdf.substring(base64Pdf.indexOf(",") + 1) : base64Pdf,
                            Base64.DEFAULT);
                    File dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
                    if (dir != null && !dir.exists()) dir.mkdirs();
                    File file = new File(dir, fileName != null ? fileName : "ledger.pdf");
                    try (FileOutputStream fos = new FileOutputStream(file)) {
                        fos.write(bytes);
                    }
                    Toast.makeText(MainActivity.this, "PDF सेव हुई: " + file.getName(), Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Log.e(TAG, "saveLedgerPdf failed", e);
                    Toast.makeText(MainActivity.this, "PDF सेव नहीं हो सकी", Toast.LENGTH_SHORT).show();
                }
            });
        }

        // ---- खाता-बही को सीधे Android प्रिंट डायलॉग से प्रिंट करना ----
        @JavascriptInterface
        public void printLedgerPdf(String htmlOrTitle) {
            runOnUiThread(() -> {
                try {
                    PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    String jobName = "YuvaShaktiLedger_" + System.currentTimeMillis();
                    android.print.PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(jobName);
                    printManager.print(jobName, adapter, new PrintAttributes.Builder().build());
                } catch (Exception e) {
                    Log.e(TAG, "printLedgerPdf failed", e);
                    Toast.makeText(MainActivity.this, "प्रिंट नहीं हो सका", Toast.LENGTH_SHORT).show();
                }
            });
        }

        // ---- इस ऐप की ही APK फ़ाइल दूसरों के साथ शेयर करना ----
        @JavascriptInterface
        public void shareAppApk() {
            runOnUiThread(() -> {
                try {
                    File apk = new File(getApplicationInfo().sourceDir);
                    File dir = new File(getCacheDir(), "apks");
                    if (!dir.exists()) dir.mkdirs();
                    File copy = new File(dir, "YuvaShaktiGroup.apk");
                    try (java.io.InputStream in = new java.io.FileInputStream(apk);
                         FileOutputStream out = new FileOutputStream(copy)) {
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, FILE_PROVIDER_AUTHORITY, copy);
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType("application/vnd.android.package-archive");
                    intent.putExtra(Intent.EXTRA_STREAM, uri);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(Intent.createChooser(intent, "ऐप शेयर करें"));
                } catch (Exception e) {
                    Log.e(TAG, "shareAppApk failed", e);
                    Toast.makeText(MainActivity.this, "APK शेयर नहीं हो सकी", Toast.LENGTH_SHORT).show();
                }
            });
        }

        // ---- किसी नई APK को डाउनलोड कर इंस्टॉलर खोलना (अपडेट डाउनलोड लिंक से) ----
        @JavascriptInterface
        public void downloadAndInstall(String url) {
            runOnUiThread(() -> {
                try {
                    android.app.DownloadManager.Request request =
                            new android.app.DownloadManager.Request(Uri.parse(url));
                    request.setDestinationInExternalFilesDir(MainActivity.this,
                            Environment.DIRECTORY_DOWNLOADS, "YuvaShaktiGroup_update.apk");
                    request.setNotificationVisibility(
                            android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    android.app.DownloadManager dm =
                            (android.app.DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    dm.enqueue(request);
                    Toast.makeText(MainActivity.this, "अपडेट डाउनलोड हो रही है...", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Log.e(TAG, "downloadAndInstall failed", e);
                    Toast.makeText(MainActivity.this, "डाउनलोड शुरू नहीं हो सकी", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
